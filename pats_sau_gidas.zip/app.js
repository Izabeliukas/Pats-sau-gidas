
function startApp() {
  document.getElementById('welcome-screen').style.display = 'none';
  document.getElementById('guide-screen').style.display = 'block';
}
